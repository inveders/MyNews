
package com.example.inved.mynews;


public class Blog {


}
