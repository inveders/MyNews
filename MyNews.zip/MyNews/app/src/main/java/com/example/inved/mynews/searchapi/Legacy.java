
package com.example.inved.mynews.searchapi;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Legacy {

    @SerializedName("xlarge")
    @Expose
    public String xlarge;
    @SerializedName("xlargewidth")
    @Expose
    public Integer xlargewidth;
    @SerializedName("xlargeheight")
    @Expose
    public Integer xlargeheight;
    @SerializedName("wide")
    @Expose
    public String wide;
    @SerializedName("widewidth")
    @Expose
    public Integer widewidth;
    @SerializedName("wideheight")
    @Expose
    public Integer wideheight;
    @SerializedName("thumbnail")
    @Expose
    public String thumbnail;
    @SerializedName("thumbnailwidth")
    @Expose
    public Integer thumbnailwidth;
    @SerializedName("thumbnailheight")
    @Expose
    public Integer thumbnailheight;

}
